<?php
$servername = "localhost";
$username = "root";
$password = "217711";
$dbname = "recipe_app";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname, "3307");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

Create database recipe_app;
DROP DATABASE sakila;

USE recipe_app;

CREATE TABLE studnet (
id INT PRIMARY KEY,
name VARCHAR(50),
age INT NOT NULL
);